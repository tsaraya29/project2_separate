DROP DATABASE IF EXISTS cupcakes;
CREATE DATABASE cupcakes;
USE cupcakes;