INSERT INTO Customers(firstName, lastName, email, password, confirm)
Values("test", "test", "test", "test", "test")